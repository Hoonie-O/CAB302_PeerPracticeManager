package com.cab302.peerpractice.Exceptions;

public class DuplicateGroupException extends RuntimeException {
    public DuplicateGroupException(String message) {
        super(message);
    }
}
