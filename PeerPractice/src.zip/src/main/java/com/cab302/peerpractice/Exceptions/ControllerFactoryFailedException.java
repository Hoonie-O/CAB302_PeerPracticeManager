package com.cab302.peerpractice.Exceptions;

public class ControllerFactoryFailedException extends RuntimeException {
    public ControllerFactoryFailedException(String message) {
        super(message);
    }
}
