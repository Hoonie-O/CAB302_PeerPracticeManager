package com.cab302.peerpractice;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(PeerPracticeApplication.class, args);
    }
}
