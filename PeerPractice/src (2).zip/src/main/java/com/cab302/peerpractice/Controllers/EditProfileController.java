package com.cab302.peerpractice.Controllers;

import com.cab302.peerpractice.AppContext;
import com.cab302.peerpractice.Navigation;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

public class EditProfileController extends BaseController {
    @FXML private StackPane root;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private TextField usernameField;
    @FXML private TextField phoneField;
    @FXML private TextField addressField;
    @FXML private TextField instituteField;
    @FXML private DatePicker dateOfBirthField;

    protected EditProfileController(AppContext ctx, Navigation nav) {
        super(ctx, nav);
    }

    /** Show/hide from parent controller */
    public void show() {
        root.setVisible(true);
        root.setManaged(true);
    }
    public void hide() {
        root.setVisible(false);
        root.setManaged(false);
    }

    @FXML private void onClose() {
        hide();
    }

    @FXML private void onSave() {
        // TODO: validate & persist changes
        hide();
    }
}